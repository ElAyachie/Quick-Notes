package com.example.oulalm.quickmaths;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.Image;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ListsCustomAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<String> noteContentList;

    ListsCustomAdapter(Context context, ArrayList<String> noteContent) {
        this.context = context;
        this.noteContentList = noteContent;
    }

    @Override
    public int getCount() {
        return noteContentList.size();
    }

    @Override
    public Object getItem(int position) {
        return this.noteContentList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return this.noteContentList.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        @SuppressLint("ViewHolder") View view = View.inflate(this.context, R.layout.new_list_view, null);
        TextView contentText = view.findViewById(R.id.contentText);
        contentText.setText(noteContentList.get(position));

        return view;
    }
}

