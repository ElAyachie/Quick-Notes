package com.example.oulalm.quickmaths;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Note {
    public static void saveNote(Context context, String folderName, String noteName, String content) {
        String filePath = context.getFilesDir().getAbsolutePath() + "/" + "Notes";
        try {
            String fileName = noteName + ".txt";
            //files get saved inside of the folder the user chooses
            filePath = filePath + "/" + folderName;
            File file = new File(filePath, fileName);
            //stream can be used to write into the file
            FileOutputStream stream = new FileOutputStream(file);
            stream.write(content.getBytes());
            stream.close();
        } catch (IOException e) {
            Log.e("Exception", "File write failed: " + e.toString());
        }
    }

    public static void saveFolderName(Context context, String folderName) {
        try {
            // append to file
            String filePath = context.getFilesDir().getAbsolutePath() + "/" + "Notes" + "/" + "folderNames.txt";
            FileOutputStream fos = context.openFileOutput("folderNames.txt", Context.MODE_APPEND);
            fos.write(folderName.getBytes());
            fos.write('\n');
            fos.close();
        } catch (IOException e) {
            Log.e("Tab2Fragment", "Can not read file: " + e.toString());
        }
    }

    private static boolean fileExists(Context context, String fileName) {
        String filePath = context.getFilesDir().getAbsolutePath() + "/" + "Notes";
        File file = new File(filePath, fileName);
        return file.exists();
    }

    private static boolean folderExists(Context context, String folderName) {
        File file = new File(context.getFilesDir().getAbsolutePath() + "/" + "Notes" + "/" + folderName);
        return file.isDirectory();
    }

    public static ArrayList<String> loadNotesInFolder(Context context, String folderName) {
        ArrayList<String> noteNames = new ArrayList<>();
        String filePath = context.getFilesDir().getAbsolutePath() + "/" + "Notes" + "/";
        filePath = filePath + "/" + folderName;
        File dir = new File(filePath);
        File[] directoryListing = dir.listFiles();
        if (directoryListing != null) {
            for (File child : directoryListing) {
                noteNames.add(child.getName().substring(0, child.getName().length() - 4));
            }
        } else {
            System.out.println("File is not a folder.");
        }
        return noteNames;
    }

    public static ArrayList<String> loadAllNoteContentInFolder(Context context, String folderName) {
        String filePath = context.getFilesDir().getAbsolutePath() + "/" + "Notes";
        ArrayList<String> noteContent = new ArrayList<>();
        filePath = filePath + "/" + folderName;
        File dir = new File(filePath);
        File[] directoryListing = dir.listFiles();
        if (directoryListing != null) {
            for (File child : directoryListing) {
                noteContent.add(loadNote(context, child.getName(), folderName));
            }
        } else {
            System.out.println("File is not a folder.");
        }
        return noteContent;
    }

    private static String loadNote(Context context, String noteName, String folderName) {
        String filePath = context.getFilesDir() + "/" + "Notes" + "/" + folderName + "/" + noteName;
        StringBuilder noteContent = new StringBuilder();
        int counter = 0;
        try {
            FileInputStream inputStream = new FileInputStream(new File(filePath));
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            String receiveString;
            while ((receiveString = bufferedReader.readLine()) != null) {
                if (counter > 0) {
                    noteContent.append('\n');
                }
                noteContent.append(receiveString);
                counter++;
            }
            inputStream.close();
        } catch (FileNotFoundException e) {
            Log.e("Note", "File not found: " + e.toString());
        } catch (IOException e) {
            Log.e("Note", "Can not read file: " + e.toString());
        }
        return noteContent.toString();
    }

    public static ArrayList<String> loadFolderNames(Context context) {
        ArrayList<String> folderNamesList = new ArrayList<>();
        String filePath = context.getFilesDir().getAbsolutePath();
        try {
            if (!folderExists(context, "Notes")) {
                File folder = new File(filePath, "Notes");
                folder.mkdir();
                File folder1 = new File(filePath + "/" + "Notes", "Unclassified");
                folder1.mkdir();
            }
            if (fileExists(context, "Notes" + "/" + "folderNames.txt")) {
                FileInputStream inputStream = new FileInputStream(new File(filePath + "/" + "Notes" + "/" + "folderNames.txt"));
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString;
                while ((receiveString = bufferedReader.readLine()) != null) {
                    folderNamesList.add(receiveString);
                }
                inputStream.close();
            } else {
                File file = new File(filePath + "/" + "Notes", "folderNames.txt");
                FileOutputStream fos = new FileOutputStream (new File(filePath + "/" + "Notes" + "/" + "folderNames.txt"), true);
                //FileOutputStream fos = context.openFileOutput(filePath + "/" + "Notes" + "/" + "folderNames.txt", Context.MODE_APPEND);
                folderNamesList.add("Unclassified");
                fos.write("Unclassified".getBytes());
                fos.write('\n');
                fos.close();
            }

        } catch (
                FileNotFoundException e)

        {
            Log.e("Note", "File not found: " + e.toString());
        } catch (
                IOException e)

        {
            Log.e("Note", "Can not read file: " + e.toString());
        }
        return folderNamesList;
    }

    public static void deleteNote(Context context, String noteName, String folderName) {
        String filePath = context.getFilesDir().getAbsolutePath() + "/" + "Notes" + "/" + folderName + "/" + noteName + ".txt";
        File fileOrDirectory = new File(filePath);
        fileOrDirectory.delete();
    }

    public static void deleteFolder(Context context, String folderName) {
        String filePath = context.getFilesDir().getAbsolutePath() + "/" + "Notes" + "/" + folderName;
        File fileOrDirectory = new File(filePath);
        if (fileOrDirectory.isDirectory()) {
            for (File child : fileOrDirectory.listFiles()) {
                deleteFolder(context, folderName + "/" + child.getName());
            }
        }
        fileOrDirectory.delete();
        try {
            filePath = context.getFilesDir().getAbsolutePath() + "/" + "Notes";
            File file = new File(filePath, "folderNames.txt");
            removeLine(file, folderName);
        } catch (IOException e) {
            Log.e("Note", "Can not read file: " + e.toString());
        }
    }

    @SuppressLint("Assert")
    private static void removeLine(final File file, final String line) throws IOException {
        final List<String> lines = new LinkedList<>();
        final Scanner reader = new Scanner(new FileInputStream(file), "UTF-8");
        while (reader.hasNext()) {
            String nextLine = reader.nextLine();
            if (!line.equals(nextLine)) {
                lines.add(nextLine);
            }
        }
        reader.close();
        final BufferedWriter writer = new BufferedWriter(new FileWriter(file, false));
        for (final String line1 : lines)
            writer.write(line1);
        writer.write('\n');
        writer.flush();
        writer.close();
    }
}
