package com.example.oulalm.quickmaths;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Locale;


/*might not be using(would need to make an xml file) for just doing percentage of a price(quick).*/
public class PercentageOff extends AppCompatActivity {
    double defaultSalesTax = 6.25;
    TextView totalTextView;
    EditText percentageTxt;
    EditText numberTxt;
    Switch salesTaxSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        totalTextView = findViewById(R.id.totalTextView);
        percentageTxt = findViewById(R.id.percentageTxt);
        numberTxt = findViewById(R.id.numberTxt);
        salesTaxSwitch = findViewById(R.id.salesTaxSwitch);

        //casting to Button, so it can be used as a button
        Button calcBtn = findViewById(R.id.calcBtn);
        calcBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (((numberTxt.getText().toString()).matches("")) && ((percentageTxt.getText().toString()).matches(""))) {
                    numberTxt.setError("Please enter a name.");
                    percentageTxt.setError("Please enter a price.");
                } else if ((percentageTxt.getText().toString()).matches("")) {
                    percentageTxt.setError("Please enter a percentage.");
                } else if ((numberTxt.getText().toString()).matches("")) {
                    numberTxt.setError("Please enter a number.");
                } else {
                    if (salesTaxSwitch.isChecked()) {
                        float percentage = Float.parseFloat(percentageTxt.getText().toString());
                        float dec = 1 - (percentage / 100);
                        float subTotal = dec * Float.parseFloat(numberTxt.getText().toString());
                        float decimalTax = (float) (defaultSalesTax / 100);
                        float total = subTotal + (subTotal * decimalTax);
                        totalTextView.setText(String.format(Locale.getDefault(), "%,.2f", total));
                    } else {
                        float percentage = Float.parseFloat(percentageTxt.getText().toString());
                        float dec = 1 - (percentage / 100);
                        float total = dec * Float.parseFloat(numberTxt.getText().toString());
                        totalTextView.setText(String.format(Locale.getDefault(), "%,.2f", total));
                    }
                }
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
