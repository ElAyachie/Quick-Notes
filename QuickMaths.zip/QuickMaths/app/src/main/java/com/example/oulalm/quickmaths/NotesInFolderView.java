package com.example.oulalm.quickmaths;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Objects;

public class NotesInFolderView extends AppCompatActivity {
    TextView folderNameView;
    @SuppressLint("StaticFieldLeak")
    static ListView notesFolderListView;
    //key is folder name
    static String currentFolder;
    static ArrayList<String> allNotesContent = new ArrayList<>();
    static ArrayList<String> allNoteNames = new ArrayList<>();
    String filePath;
    @SuppressLint("StaticFieldLeak")
    static NotesCustomAdapter notesAdapter;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notes_in_folder_view);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);


        folderNameView = findViewById(R.id.folderNameView);
        notesFolderListView = findViewById(R.id.notesFolderListView);
        filePath = getFilesDir().getAbsolutePath();
        currentFolder = getIntent().getStringExtra("Folder Name");
        folderNameView.setText(currentFolder);
        allNoteNames = Note.loadNotesInFolder(this, currentFolder);
        allNotesContent = Note.loadAllNoteContentInFolder(this, currentFolder);
        notesAdapter = new NotesCustomAdapter(this, allNoteNames, allNotesContent);
        notesFolderListView.setAdapter(notesAdapter);


        notesFolderListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(view.getContext(), SpecificNoteEdit.class);
                String clickedNoteName = notesFolderListView.getItemAtPosition(position).toString();
                String clickedNoteContent = allNotesContent.get(position);
                intent.putExtra("Folder name", currentFolder);
                intent.putExtra("Note name",clickedNoteName);
                intent.putExtra("Note content", clickedNoteContent);
                startActivity(intent);
            }
        });

        notesFolderListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                final String longClickedNoteName = notesFolderListView.getItemAtPosition(position).toString();
                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                final TextView message = new TextView(view.getContext());
                message.setTextSize(20);
                message.setTextColor(Color.BLACK);
                message.setGravity(Gravity.CENTER_HORIZONTAL);
                message.setText("Delete this note?");
                builder.setView(message);
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Note.deleteNote(getBaseContext(), longClickedNoteName, currentFolder);
                        refreshFolderListView(getBaseContext());
                        notesFolderListView.setAdapter(notesAdapter);
                        Toast.makeText(getBaseContext(), "Note deleted.", Toast.LENGTH_LONG).show();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
                return true;
            }
        });

}

    public static void refreshFolderListView(Context context){
        allNoteNames = Note.loadNotesInFolder(context, currentFolder);
        allNotesContent = Note.loadAllNoteContentInFolder(context, currentFolder);
        notesAdapter = new NotesCustomAdapter(context, allNoteNames, allNotesContent);
        notesFolderListView.setAdapter(notesAdapter);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
