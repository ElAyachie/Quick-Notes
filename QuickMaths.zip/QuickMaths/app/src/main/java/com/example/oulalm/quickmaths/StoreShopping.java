package com.example.oulalm.quickmaths;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Locale;

public class StoreShopping extends AppCompatActivity {
    FloatingActionButton addItemBtn;
    Button clearListBtn;
    Button saveListBtn;
    EditText itemNameText;
    EditText itemPriceText;
    EditText discountText;
    TextView totalCostView;
    ArrayList<String> itemList = new ArrayList<>();
    ArrayAdapter<String> adapterItemListView;
    static ArrayList<String> folderNamesList = new ArrayList<>();
    private static ArrayAdapter folderNamesListAdapter;
    ListView itemListView;
    Switch salesTaxSwitch;
    float itemPrice;
    float billTotal = 0;
    float taxedBillTotal = 0;
    float chosenBill = 0;
    double defaultSalesTax = 6.25;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_store_shopping);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //setting up navigation bar
        final DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                String title = (String) item.getTitle();
                Intent intent;
                switch (title) {
                    case "Quick Notes":
                        intent = new Intent(StoreShopping.this, HomePageTest.class);
                        startActivity(intent);
                        break;
                    case "Store Shopping":
                        drawer.closeDrawers();
                        break;
                    case "Restaurant":
                        intent = new Intent(StoreShopping.this, Restaurant.class);
                        startActivity(intent);
                        break;
                    case "Unit Conversion":
                        intent = new Intent(StoreShopping.this, UnitConversion.class);
                        startActivity(intent);
                        break;
                }
                return false;
            }
        });
        //done setting up navigation bar

        //linking xml with java
        itemPriceText = findViewById(R.id.itemPriceText);
        itemNameText = findViewById(R.id.itemNameText);
        salesTaxSwitch = findViewById(R.id.salesTaxSwitch);
        itemListView = findViewById(R.id.itemListView);
        totalCostView = findViewById(R.id.totalCostTextView);
        discountText = findViewById(R.id.discountText);

        adapterItemListView = new ArrayAdapter<>(StoreShopping.this, R.layout.new_list_view, itemList);
        itemListView.setAdapter(adapterItemListView);

        //when user wants to create a new folder
        addItemBtn = findViewById(R.id.addItemBtn);
        addItemBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String itemNameString = itemNameText.getText().toString();
                if (itemNameString.equals("")) {
                    itemNameText.setError("Please enter a name(or else blank).");
                }
                if (itemPriceText.getText().toString().equals("")) {
                    itemPriceText.setError("Please enter a price.");
                } else {
                    itemPrice = Float.parseFloat(itemPriceText.getText().toString());
                    //discount label has value
                    String discountString = discountText.getText().toString();
                    if (!discountString.equals("")) {
                        float percentage = Float.parseFloat(discountString);
                        float dec = 1 - (percentage / 100);
                        itemPrice = itemPrice * dec;
                    }
                    billTotal += itemPrice;
                    if (salesTaxSwitch.isChecked()) {
                        float decimalTax = (float) (defaultSalesTax / 100);
                        taxedBillTotal = billTotal + (billTotal * decimalTax);
                        //chosenBil is for the tip add on
                        chosenBill = taxedBillTotal;
                    } else {
                        chosenBill = billTotal;
                    }
                    totalCostView.setText(String.format(Locale.getDefault(), "$%,.2f", chosenBill));
                    int amountSpaces = (-1 * (16 - itemNameString.length()));
                    String formatForName = "%" + amountSpaces + "s";
                    itemList.add(" " + itemNameString + String.format(Locale.getDefault(), formatForName + "$%,.2f", "",
                            itemPrice));
                    adapterItemListView.notifyDataSetChanged();
                    itemPriceText.setText("");
                    itemNameText.setText("");
                    discountText.setText("");
                }
            }
        });

        //clear the list
        clearListBtn = findViewById(R.id.clearListBtn);
        clearListBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                itemList.clear();
                adapterItemListView.notifyDataSetChanged();
                billTotal = 0;
                totalCostView.setText("");
            }
        });


        //creating a list
        saveListBtn = findViewById(R.id.saveListBtn);
        saveListBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(StoreShopping.this);
                builder.setTitle("Save List");

                LinearLayout layout = new LinearLayout(getBaseContext());
                layout.setOrientation(LinearLayout.VERTICAL);
                final EditText listName = new EditText(getBaseContext());
                listName.setHint("List name");
                listName.setInputType(InputType.TYPE_CLASS_TEXT);
                layout.addView(listName);
                final Spinner folderSpin = new Spinner(getBaseContext());
                folderNamesList = Note.loadFolderNames(getBaseContext());
                folderNamesListAdapter = new ArrayAdapter<>(getBaseContext(), android.R.layout.simple_list_item_1, folderNamesList);
                folderNamesListAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                folderSpin.setAdapter(folderNamesListAdapter);
                layout.addView(folderSpin);

                //formatting the list so that it looks good in the collection screen
                final StringBuilder formattedItemList = new StringBuilder("");
                for (int i = 0; itemList.size() > i; i++) {
                    formattedItemList.append(itemList.get(i)).append('\n');
                }

                //setting up the spinner with folder names
                builder.setView(layout);
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (!listName.getText().toString().equals("")) {
                            String noteName = listName.getText().toString();
                            String folderName = folderSpin.getSelectedItem().toString();
                            Note.saveNote(getBaseContext(), folderName, noteName, formattedItemList.toString());
                            Toast.makeText(getBaseContext(), "List saved.", Toast.LENGTH_LONG).show();
                        }
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
            }
        });

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
