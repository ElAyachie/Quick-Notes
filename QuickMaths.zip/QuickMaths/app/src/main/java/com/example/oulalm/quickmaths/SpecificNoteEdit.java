package com.example.oulalm.quickmaths;

import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;


public class SpecificNoteEdit extends AppCompatActivity {
    String currentFolder;
    String currentNote;
    String currentNoteContent;
    EditText noteNameText;
    EditText noteContentText;
    RelativeLayout relativeLayout;
    ImageButton confirmChangesBtn;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.specific_note_edit);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        confirmChangesBtn = findViewById(R.id.confirmChangeBtn);
        relativeLayout = findViewById(R.id.relativeLayout);
        noteNameText = findViewById(R.id.noteNameText);
        noteContentText = findViewById(R.id.noteContentText);
        currentFolder = getIntent().getStringExtra("Folder name");
        currentNote = getIntent().getStringExtra("Note name");
        currentNoteContent = getIntent().getStringExtra("Note content");
        noteNameText.setText(currentNote);
        noteContentText.setText(currentNoteContent);
        noteContentText.setSelection(noteContentText.getText().length());
        noteContentText.requestFocus();

        confirmChangesBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentNote.equals(noteNameText.getText().toString())) {
                    Note.saveNote(getBaseContext(), currentFolder, noteNameText.getText().toString(), noteContentText.getText().toString());
                    NotesInFolderView.refreshFolderListView(getBaseContext());
                    Toast.makeText(getBaseContext(), "Note saved.", Toast.LENGTH_LONG).show();
                } else {
                    Note.deleteNote(getBaseContext(), currentNote, currentFolder);
                    Note.saveNote(getBaseContext(), currentFolder, noteNameText.getText().toString(), noteContentText.getText().toString());
                    NotesInFolderView.refreshFolderListView(getBaseContext());
                    Toast.makeText(getBaseContext(), "Note saved.", Toast.LENGTH_LONG).show();

                }
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
