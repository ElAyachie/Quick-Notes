package com.example.oulalm.quickmaths;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Tab3Fragment extends Fragment {
    FloatingActionButton addItemBtn;
    Button clearListBtn;
    Button saveListBtn;
    EditText contentText;
    ArrayList<String> contentList = new ArrayList<>();
    ListsCustomAdapter adapterContentListView;
    static ArrayList<String> folderNamesList = new ArrayList<>();
    private static ArrayAdapter folderNamesListAdapter;
    ListView contentListView;

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab3_fragment, container, false);

        //linking xml with java
        contentText = view.findViewById(R.id.contentText);
        //changed enter key press to add a list item
        contentText.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER))) {
                    addItemBtn.performClick();
                    return true;
                }
                return false;
            }
        });

        contentListView = view.findViewById(R.id.contentListView);
        adapterContentListView = new

                ListsCustomAdapter(getContext(), contentList);
        contentListView.setAdapter(adapterContentListView);

        //when user wants to create a new folder
        addItemBtn = view.findViewById(R.id.addItemBtn);
        addItemBtn.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick(View view) {
                String contentString = contentText.getText().toString();
                if (contentString.equals("")) {
                    contentText.setError("Please enter a name(or else blank).");
                } else {
                    contentList.add(" " + contentString);
                }
                adapterContentListView.notifyDataSetChanged();
                contentText.setText("");
            }
        });

        //clear the list
        clearListBtn = view.findViewById(R.id.clearListBtn);
        clearListBtn.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick(View view) {
                contentList.clear();
                adapterContentListView.notifyDataSetChanged();
            }
        });


        //creating a list
        saveListBtn = view.findViewById(R.id.saveListBtn);
        saveListBtn.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setTitle("Save List");

                LinearLayout layout = new LinearLayout(getContext());
                layout.setOrientation(LinearLayout.VERTICAL);
                final EditText listName = new EditText(getContext());
                listName.setHint("List name");
                listName.setInputType(InputType.TYPE_CLASS_TEXT);
                layout.addView(listName);
                final Spinner folderSpin = new Spinner(getContext());
                folderNamesList = Note.loadFolderNames(getContext());
                folderNamesListAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, folderNamesList);
                folderNamesListAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                folderSpin.setAdapter(folderNamesListAdapter);
                layout.addView(folderSpin);

                //formatting the list so that it looks good in the collection screen
                final StringBuilder formattedItemList = new StringBuilder("");
                for (int i = 0; contentList.size() > i; i++) {
                    formattedItemList.append(contentList.get(i)).append('\n');
                }

                //setting up the spinner with folder names
                builder.setView(layout);
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (!listName.getText().toString().equals("")) {
                            String noteName = listName.getText().toString();
                            String folderName = folderSpin.getSelectedItem().toString();
                            Note.saveNote(getContext(), folderName, noteName, formattedItemList.toString());
                            Toast.makeText(getContext(), "List saved.", Toast.LENGTH_LONG).show();
                        }
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
            }
        });
        return view;
    }
}
