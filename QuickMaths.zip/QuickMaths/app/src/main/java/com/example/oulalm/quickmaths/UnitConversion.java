package com.example.oulalm.quickmaths;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class UnitConversion extends AppCompatActivity {
    //assigning values to the unit lists
    String[] measurementArray = {"Temperature", "Area", "Volume", "Length", "Mass", "Time", "Currency"};
    String[] temperatureUnitArray = {"Fahrenheit", "Celsius", "Kelvin"};
    String[] lengthUnitArray = {"Meter", "Kilometer", "Centimeter", "Millimeter", "Micrometer", "Nanometer", "Mile", "Yard", "Foot", "Inch", "Light Year"};
    String[] areaUnitArray = {"Square Meter", "Square Kilometer", "Square Mile", "Square Yard", "Square Foot", "Square Inch", "Hectare", "Acre"};
    String[] volumeUnitArray = {"US liquid gallon", "US liquid quart", "US legal cup", "US fluid ounce", "US tablespoon", "Cubic meter", "Liter", "Milliliter"
            , "Imperial quart", "Imperial pint", "Imperial cup", "Imperial fluid ounce", "Imperial tablespoon", "Imperial teaspoon", "Cubic foot", "Cubic inch"};
    String[] massUnitArray = {"Metric ton", "Kilograms", "Grams", "Milligrams", "Micrograms", "Imperial ton", "US ton", "Stone", "Pound", "Ounce"};


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_unit_conversion);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //setting up navigation bar
        final DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                String title = (String) item.getTitle();
                Intent intent;
                switch (title) {
                    case "Quick Notes":
                        intent = new Intent(UnitConversion.this, HomePageTest.class);
                        startActivity(intent);
                        break;
                    case "Store Shopping":
                        intent = new Intent(UnitConversion.this, StoreShopping.class);
                        startActivity(intent);
                        break;
                    case "Restaurant":
                        intent = new Intent(UnitConversion.this, Restaurant.class);
                        startActivity(intent);
                        break;
                    case "Unit Conversion":
                        drawer.closeDrawers();
                        break;
                }
                return false;
            }
        });

        //assigning values for measurement spinner
        //and what is gonna be used in the change of price
        ArrayAdapter<String> measurementListAdapter = new ArrayAdapter<>(UnitConversion.this, android.R.layout.simple_list_item_1, measurementArray);
        measurementListAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        final Spinner measurementSelectionSpin = findViewById(R.id.measurementSelectionSpin);
        final Spinner fromMeasurementSpin = findViewById(R.id.fromMeasurementSpin);
        final Spinner toMeasurementSpin = findViewById(R.id.toMeasurementSpin);
        final EditText fromMeasurementInput = findViewById(R.id.fromMeasurementInput);
        final TextView toMeasurementView = findViewById(R.id.toMeasurementView);
        measurementSelectionSpin.setAdapter(measurementListAdapter);
        measurementSelectionSpin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                final String currentMeasurement = measurementSelectionSpin.getSelectedItem().toString();
                switch (currentMeasurement) {
                    case "Length":
                        ArrayAdapter<String> fromMeasurementAdapter = new ArrayAdapter<>(UnitConversion.this, android.R.layout.simple_list_item_1, lengthUnitArray);
                        fromMeasurementSpin.setAdapter(fromMeasurementAdapter);
                        ArrayAdapter<String> toMeasurementAdapter = new ArrayAdapter<>(UnitConversion.this, android.R.layout.simple_list_item_1, lengthUnitArray);
                        toMeasurementSpin.setAdapter(toMeasurementAdapter);
                        break;
                    case "Area":
                        fromMeasurementAdapter = new ArrayAdapter<>(UnitConversion.this, android.R.layout.simple_list_item_1, areaUnitArray);
                        fromMeasurementSpin.setAdapter(fromMeasurementAdapter);
                        toMeasurementAdapter = new ArrayAdapter<>(UnitConversion.this, android.R.layout.simple_list_item_1, areaUnitArray);
                        toMeasurementSpin.setAdapter(toMeasurementAdapter);
                        break;
                    case "Volume":
                        fromMeasurementAdapter = new ArrayAdapter<>(UnitConversion.this, android.R.layout.simple_list_item_1, volumeUnitArray);
                        fromMeasurementSpin.setAdapter(fromMeasurementAdapter);
                        toMeasurementAdapter = new ArrayAdapter<>(UnitConversion.this, android.R.layout.simple_list_item_1, volumeUnitArray);
                        toMeasurementSpin.setAdapter(toMeasurementAdapter);
                        break;
                    case "Mass":
                        fromMeasurementAdapter = new ArrayAdapter<>(UnitConversion.this, android.R.layout.simple_list_item_1, massUnitArray);
                        fromMeasurementSpin.setAdapter(fromMeasurementAdapter);
                        toMeasurementAdapter = new ArrayAdapter<>(UnitConversion.this, android.R.layout.simple_list_item_1, massUnitArray);
                        toMeasurementSpin.setAdapter(toMeasurementAdapter);
                        break;
                    default:
                        fromMeasurementAdapter = new ArrayAdapter<>(UnitConversion.this, android.R.layout.simple_list_item_1, temperatureUnitArray);
                        fromMeasurementSpin.setAdapter(fromMeasurementAdapter);
                        toMeasurementAdapter = new ArrayAdapter<>(UnitConversion.this, android.R.layout.simple_list_item_1, temperatureUnitArray);
                        toMeasurementSpin.setAdapter(toMeasurementAdapter);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
            }

        });

        //do something with input
        //there must be a different algorithm to do this so i can probably find it online
        /* might be helpful to try to come up with my own
         * ignore the beforeTextChanged and the afterTextChanged methods for now*/
        fromMeasurementInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                final String currentMeasurement = measurementSelectionSpin.getSelectedItem().toString();
                final String fromMeasurement = fromMeasurementSpin.getSelectedItem().toString();
                final String toMeasurement = toMeasurementSpin.getSelectedItem().toString();
                String input = s.toString();
                float answer = 0;
                if (!input.equals("")) {
                    //takes care of all the cases that fromMeasurement = toMeasurement
                    if (fromMeasurement.equals(toMeasurement)) {
                        answer = Float.parseFloat(input);
                    } else {
                        switch (currentMeasurement) {
                            case "Temperature":
                                answer = temperatureConversion(fromMeasurement, toMeasurement, Float.parseFloat(input));
                                break;
                            case "Length":
                                answer = lengthConversion(fromMeasurement, toMeasurement, Float.parseFloat(input));
                                break;
                            case "Area":
                                answer = areaConversion(fromMeasurement, toMeasurement, Float.parseFloat(input));
                                break;
                            case "Volume":
                                answer = volumeConversion(fromMeasurement, toMeasurement, Float.parseFloat(input));
                                break;
                            case "Mass":
                                answer = massConversion(fromMeasurement, toMeasurement, Float.parseFloat(input));
                                break;
                        }
                    }
                    //set text view for to conversion
                    toMeasurementView.setText(String.format("%s", answer));
                } else if (input.equals("")) {
                    toMeasurementView.setText("");
                }
            }

            public void afterTextChanged(Editable s) {
            }
        });
    }

    //should use a different way maybe with classes and constants, but this is for now
    //for temperature conversions
    public static float temperatureConversion(String from, String to, float fromNum) {
        //first step is to turn to Celsius
        float numInCelsius;
        switch (from) {
            case "Fahrenheit":
                numInCelsius = (fromNum - 32) * 5 / 9;
                break;
            case "Kelvin":
                numInCelsius = (float) (fromNum - 273.15);
                break;
            default:
                numInCelsius = fromNum;
        }
        switch (to) {
            case "Fahrenheit":
                return (numInCelsius * 9 / 5) + 32;
            case "Kelvin":
                return (float) (numInCelsius + 273.15);
            default:
                return numInCelsius;
        }
    }

    //for length conversion, might be a cooler way to do this with meters and using an array of numbers
    //first turn it into meters then what is needed
    //this can be optimized im just being lazy
    //could have something like fromNum * fromMeasurementNum
    public static float lengthConversion(String from, String to, float fromNum) {
        float numInMeters;
        switch (from) {
            case "Kilometer":
                numInMeters = fromNum * 1000;
                break;
            case "Centimeter":
                numInMeters = fromNum / 100;
                break;
            case "Millimeter":
                numInMeters = (float) (fromNum / Math.pow(10, 6));
                break;
            case "Micrometer":
                numInMeters = (float) (fromNum / Math.pow(10, 9));
                break;
            case "Nanometer":
                numInMeters = (float) (fromNum / Math.pow(10, 12));
                break;
            case "Mile":
                numInMeters = (float) (fromNum / 0.00062137);
                break;
            case "Yard":
                numInMeters = (float) (fromNum * .9144);
                break;
            case "Foot":
                numInMeters = (float) (fromNum * .3048);
                break;
            case "Inch":
                numInMeters = (float) (fromNum * .0254);
                break;
            default:
                numInMeters = fromNum;
        }
        switch (to) {
            case "Kilometer":
                return numInMeters / 1000;
            case "Centimeter":
                return numInMeters * 100;
            case "Millimeter":
                return (float) (numInMeters * Math.pow(10, 6));
            case "Micrometer":
                return (float) (numInMeters * Math.pow(10, 9));
            case "Nanometer":
                return (float) (numInMeters * Math.pow(10, 12));
            case "Mile":
                return (float) (numInMeters * 0.00062137);
            case "Yard":
                return (float) (numInMeters / .9144);
            case "Foot":
                return (float) (numInMeters / .3048);
            case "Inch":
                return (float) (numInMeters / .0254);
            default:
                return numInMeters;
        }
    }

    //for area conversions
    public static float areaConversion(String from, String to, float fromNum) {
        float numInSquareMeter;
        switch (from) {
            case "Square Kilometer":
                numInSquareMeter = (float) (fromNum * Math.pow(10, 6));
                break;
            case "Square Mile":
                numInSquareMeter = (float) (fromNum * (1 / .38610 * (1 / Math.pow(10, -6))));
                break;
            case "Square Yard":
                numInSquareMeter = (float) (fromNum / 1.1960);
                break;
            case "Square Foot":
                numInSquareMeter = (float) (fromNum / 10.764);
                break;
            case "Square Inch":
                numInSquareMeter = (float) (fromNum * 1550.0031);
                break;
            case "Hectare":
                numInSquareMeter = (float) (fromNum * Math.pow(10, 5));
                break;
            case "Acre":
                numInSquareMeter = (float) (fromNum * (1 / .24711 * (1 / Math.pow(10, -3))));
                break;
            default:
                numInSquareMeter = fromNum;
                break;
        }
        switch (to) {
            case "Square Kilometer":
                return (float) (numInSquareMeter / Math.pow(10, 6));
            case "Square Mile":
                return (float) (numInSquareMeter / (1 / .38610 * (1 / Math.pow(10, -6))));
            case "Square Yard":
                return (float) (numInSquareMeter * 1.1960);
            case "Square Foot":
                return (float) (numInSquareMeter * 10.764);
            case "Square Inch":
                return (float) (numInSquareMeter * 1550.0031);
            case "Hectare":
                return (float) (numInSquareMeter / Math.pow(10, 5));
            case "Acre":
                return (float) (numInSquareMeter / (1 / .24711 * (1 / Math.pow(10, -3))));
            default:
                return numInSquareMeter;
        }
    }

    //for volume conversion(cooking)
    //no way i can make a bunch of case statements for this there are too many so i have to think of a new method probably for the best to change all of the conversion methods
    public static float volumeConversion(String from, String to, float fromNum) {
        //turn into liter first
        float numInLiter;
        switch (from) {
            case "US liquid gallon":
                numInLiter = (float) (fromNum / 0.26417);
                break;
            case "US liquid quart":
                numInLiter = (float) (fromNum / 1.0567);
                break;
            case "US liquid pint":
                numInLiter = (float) (fromNum / 2.1134);
                break;
            case "US legal cup":
                numInLiter = (float) (fromNum / 4.2268);
                break;
            case "US tablespoon":
                numInLiter = (float) (fromNum / 67.628);
                break;
            case "US teaspoon":
                numInLiter = (float) (fromNum / 202.88);
                break;
            case "Cubic meter":
                numInLiter = (float) (fromNum / 0.001);
                break;
            case "Milliliter":
                numInLiter = (float) (fromNum / 1000.0);
                break;
            case "Imperial quart":
                numInLiter = (float) (fromNum / 0.87988);
                break;
            case "Imperial pint":
                numInLiter = (float) (fromNum / 1.7598);
                break;
            case "Imperial cup":
                numInLiter = (float) (fromNum / 3.51951);
                break;
            case "Imperial fluid ounce":
                numInLiter = (float) (fromNum / 35.195);
                break;
            case "Imperial tablespoon":
                numInLiter = (float) (fromNum / 70.390);
                break;
            case "Imperial teaspoon":
                numInLiter = (float) (fromNum / 281.56);
                break;
            default:
                numInLiter = fromNum;
        }
        switch (to) {
            case "US liquid gallon":
                return (float) (numInLiter * 0.26417);
            case "US liquid quart":
                return (float) (numInLiter * 1.0567);
            case "US liquid pint":
                return (float) (numInLiter * 2.1134);
            case "US legal cup":
                return (float) (numInLiter * 4.2268);
            case "US tablespoon":
                return (float) (numInLiter * 67.628);
            case "US teaspoon":
                return (float) (numInLiter * 202.88);
            case "Cubic meter":
                return (float) (numInLiter * 0.001);
            case "Milliliter":
                return (float) (numInLiter * 1000.0);
            case "Imperial quart":
                return (float) (numInLiter * 0.87988);
            case "Imperial pint":
                return (float) (numInLiter * 1.7598);
            case "Imperial cup":
                return (float) (numInLiter * 4.0);
            case "Imperial fluid ounce":
                return (float) (numInLiter * 35.195);
            case "Imperial tablespoon":
                return (float) (numInLiter * 70.390);
            case "Imperial teaspoon":
                return (float) (numInLiter * 281.56);
            default:
                return numInLiter;
        }
    }

    public static float massConversion(String from, String to, float fromNum) {
        float numInPound;
        switch (from) {
            case "Metric ton":
                numInPound = (float) (fromNum * 2204.6);
                break;
            case "Kilograms":
                numInPound = (float) (fromNum * 2.2046);
                break;
            case "Grams":
                numInPound = (float) (fromNum * (2.2046 * Math.pow(10, -3)));
                break;
            case "Milligrams":
                numInPound = (float) (fromNum * (2.2046 * Math.pow(10, -6)));
                break;
            case "Micrograms":
                numInPound = (float) (fromNum * (2.2046 * Math.pow(10, -9)));
                break;
            case "Imperial ton":
                numInPound = (float) (fromNum * 2240.0);
                break;
            case "US ton":
                numInPound = (float) (fromNum * 2000.0);
                break;
            case "Stone":
                numInPound = (float) (fromNum * 14.0);
                break;
            case "Ounce":
                numInPound = (float) (fromNum * 0.0625);
                break;
            default:
                numInPound = fromNum;
        }
        switch (to) {
            case "Metric ton":
                return (float) (numInPound / 2204.6);
            case "Kilograms":
                return (float) (numInPound / 2.2046);
            case "Grams":
                return (float) (numInPound / (2.2046 * Math.pow(10, -3)));
            case "Milligrams":
                return (float) (numInPound / (2.2046 * Math.pow(10, -6)));
            case "Micrograms":
                return (float) (numInPound / (2.2046 * Math.pow(10, -9)));
            case "Imperial ton":
                return (float) (numInPound / 2240.0);
            case "US ton":
                return (float) (numInPound / 2000.0);
            case "Stone":
                return (float) (numInPound / 14.0);
            case "Ounce":
                return (float) (numInPound / 0.0625);
            default:
                return numInPound;
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}

