package com.example.oulalm.quickmaths;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Restaurant extends AppCompatActivity {
    FloatingActionButton addItemBtn;
    Button clearListBtn;
    EditText itemNameTxt;
    EditText itemPriceTxt;
    TextView totalCostView;
    TextView tipCostView;
    TextView subtotalView;
    List<String> itemList = new ArrayList<>();
    ArrayAdapter<String> adapterItemListView;
    ListView itemListView;
    Switch salesTaxSwitch;
    Switch tipSwitch;
    float billTotal = 0;
    float taxedBillTotal = 0;
    float billTotalWithTip = 0;
    float chosenBill = 0;
    double defaultSalesTax = 6.25;
    double defaultTip = 15;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_restaurant);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //setting up navigation bar
        final DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                String title = (String) item.getTitle();
                Intent intent;
                switch (title) {
                    case "Quick Notes":
                        intent = new Intent(Restaurant.this, HomePageTest.class);
                        startActivity(intent);
                        break;
                    case "Store Shopping":
                        intent = new Intent(Restaurant.this, StoreShopping.class);
                        startActivity(intent);
                        break;
                    case "Restaurant":
                        drawer.closeDrawers();
                        break;
                    case "Unit Conversion":
                        intent = new Intent(Restaurant.this, UnitConversion.class);
                        startActivity(intent);
                        break;
                }
                return false;
            }
        });

        itemPriceTxt = findViewById(R.id.itemPriceText);
        itemNameTxt = findViewById(R.id.itemNameText);
        tipCostView = findViewById(R.id.tipCostView);
        subtotalView = findViewById(R.id.subtotalView);
        salesTaxSwitch = findViewById(R.id.salesTaxSwitch);
        tipSwitch = findViewById(R.id.tipSwitch);
        itemListView = findViewById(R.id.itemListView);
        totalCostView = findViewById(R.id.totalCostTextView);
        adapterItemListView = new ArrayAdapter<>(Restaurant.this, R.layout.new_list_view, itemList);
        itemListView.setAdapter(adapterItemListView);


        addItemBtn = findViewById(R.id.addItemBtn);
        addItemBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (itemNameTxt.getText().toString().equals("")) {
                    itemNameTxt.setError("Please enter a name(or else blank).");
                }
                if (itemPriceTxt.getText().toString().equals("")) {
                    itemPriceTxt.setError("Please enter a price.");
                } else {
                    billTotal += Float.parseFloat(itemPriceTxt.getText().toString());
                    subtotalView.setText(String.format(Locale.getDefault(), "$%,.2f", billTotal));
                    float decimalTax = (float) (defaultSalesTax / 100);
                    if (salesTaxSwitch.isChecked()) {
                        taxedBillTotal = billTotal + (billTotal * decimalTax);
                        //chosenBil is for the tip add on
                        chosenBill = taxedBillTotal;
                    } else {
                        chosenBill = billTotal;
                    }
                    totalCostView.setText(String.format(Locale.getDefault(), "$%,.2f", chosenBill));
                    if (tipSwitch.isChecked()) {
                        float decimalTip = (float) (defaultTip / 100);
                        billTotalWithTip = chosenBill + (chosenBill * decimalTip);
                        tipCostView.setText((String.format(Locale.getDefault(), "$%,.2f", (chosenBill * decimalTip))));
                        totalCostView.setText(String.format(Locale.getDefault(), "$%,.2f", billTotalWithTip));
                    } else {
                        tipCostView.setText("");
                    }
                    int amountSpaces = (-1 * (16 - itemNameTxt.getText().toString().length()));
                    String formatForName = "%" + amountSpaces + "s";
                    itemList.add(" " + itemNameTxt.getText().toString() + String.format(Locale.getDefault(), formatForName + "$%,.2f", "",
                            Float.parseFloat(itemPriceTxt.getText().toString())));
                    adapterItemListView.notifyDataSetChanged();
                    itemPriceTxt.setText("");
                    itemNameTxt.setText("");
                }
            }
        });

        clearListBtn = findViewById(R.id.clearListBtn);
        clearListBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                itemList.clear();
                adapterItemListView.notifyDataSetChanged();
                billTotal = 0;
                totalCostView.setText("");
                subtotalView.setText("");
                tipCostView.setText("");
            }
        });
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
