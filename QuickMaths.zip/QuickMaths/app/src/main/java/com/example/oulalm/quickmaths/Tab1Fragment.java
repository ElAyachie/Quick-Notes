package com.example.oulalm.quickmaths;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;


public class Tab1Fragment extends Fragment {
    private static ArrayAdapter folderNamesListAdapter;
    ImageButton addNoteButton;
    @SuppressLint("StaticFieldLeak")
    static TextInputEditText noteContextText;
    @SuppressLint("StaticFieldLeak")
    static EditText noteNameText;
    @SuppressLint("StaticFieldLeak")
    static Spinner folderSpin;
    static ArrayList<String> folderNamesList = new ArrayList<>();
    @SuppressLint("StaticFieldLeak")
    static Context context;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab1_fragment, container, false);
        context = getContext();
        noteNameText = view.findViewById(R.id.noteNameText);
        folderSpin = view.findViewById(R.id.folderSpin);
        noteContextText = view.findViewById(R.id.noteContextText);
        //setting up the spinner with folder names
        folderNamesList = Note.loadFolderNames(getContext());
        folderNamesListAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, folderNamesList);
        folderNamesListAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        folderSpin.setAdapter(folderNamesListAdapter);

        addNoteButton = view.findViewById(R.id.addNoteButton);
        addNoteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String noteNameString = noteNameText.getText().toString();
                String noteString = noteContextText.getText().toString();
                if (noteNameString.equals("")) {
                    noteNameText.setError("Please enter a name(or else blank).");
                }
                if (noteString.equals("")) {
                    noteContextText.setError("Please enter a note.");
                } else {
                    Note.saveNote(getContext(), folderSpin.getSelectedItem().toString(), noteNameString, noteString);
                    updateTextFields();
                    Toast.makeText(getContext(), "Note saved.", Toast.LENGTH_LONG).show();
                }
            }
        });
        return view;
    }

    public static void refreshFolderSpinner(){
        folderNamesList = Note.loadFolderNames(context);
        folderNamesListAdapter = new ArrayAdapter<>(context, android.R.layout.simple_list_item_1, folderNamesList);
        folderNamesListAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        folderSpin.setAdapter(folderNamesListAdapter);
    }
    public static void updateTextFields(){
        noteNameText.setText("");
        noteContextText.setText("");
    }
    }
