package com.example.oulalm.quickmaths;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.text.InputType;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;

public class Tab2Fragment extends Fragment {
    ArrayAdapter<String> folderNamesTextViewAdapter;
    ListView folderNamesListView;
    TextView folderNameView;
    Button newFolderBtn;
    String filePath;
    Context context;
    ArrayList<String> folderNamesList;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab2_fragment, container, false);
        folderNamesListView = view.findViewById(R.id.notesFolderListView);
        folderNameView = view.findViewById(R.id.folderNameView);
        newFolderBtn = view.findViewById(R.id.newFolderBtn);
        context = getContext();
        filePath = context.getFilesDir().getAbsolutePath();
        folderNamesList = Note.loadFolderNames(context);
        folderNamesTextViewAdapter = new ArrayAdapter<>(context, R.layout.folders_list_view, folderNamesList);
        folderNamesListView.setAdapter(folderNamesTextViewAdapter);

        //if a user presses the new folder button they can enter a name for folder and list view
        // will be updated.
        newFolderBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setTitle("New Folder");
                // Set up the input
                final EditText folderName = new EditText(getContext());
                folderName.setInputType(InputType.TYPE_CLASS_TEXT);
                builder.setView(folderName);
                folderName.setHint("Name");
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        final String folderNameString = folderName.getText().toString();
                        if (!folderNameString.equals("")) {
                            //creating a folder to store notes
                            File folder = new File(getContext().getFilesDir(), folderNameString);
                            folder.mkdir();
                            Note.saveFolderName(getContext(), folderNameString);
                            folderNamesList.add(folderNameString);
                            folderNamesTextViewAdapter.notifyDataSetChanged();
                            Tab1Fragment.refreshFolderSpinner();
                        } else {
                            folderName.setError("Enter name.");
                        }
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
            }
        });

        //on item long click, the user will be asked if user wants to delete the folder.
        folderNamesListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                final String longClickedFolderName = folderNamesListView.getItemAtPosition(position).toString();
                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                final TextView message = new TextView(view.getContext());
                message.setTextSize(20);
                message.setTextColor(Color.BLACK);
                message.setGravity(Gravity.CENTER_HORIZONTAL);
                message.setText("Delete this folder?");
                //message.setText(String.format("Would you like to delete the note %s ?" , folderNamesListView.getItemAtPosition(position)));
                builder.setView(message);
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (longClickedFolderName.equals("Unclassified")) {
                            Toast.makeText(getContext(), "Unclassified folder can't be deleted.", Toast.LENGTH_LONG).show();

                        } else {
                            Note.deleteFolder(context, longClickedFolderName);
                            folderNamesList = Note.loadFolderNames(context);
                            folderNamesTextViewAdapter = new ArrayAdapter<>(context, R.layout.folders_list_view, folderNamesList);
                            folderNamesListView.setAdapter(folderNamesTextViewAdapter);
                            Tab1Fragment.refreshFolderSpinner();
                            Toast.makeText(getContext(), "Folder deleted.", Toast.LENGTH_LONG).show();
                        }
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
                return true;
            }
        });

        //when a folder is pressed the user is taken to a page where user can view all of the
        // notes in that folder
        folderNamesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getActivity(), NotesInFolderView.class);
                String clickedFolderName = folderNamesListView.getItemAtPosition(position).toString();
                intent.putExtra("Folder Name", clickedFolderName);
                startActivity(intent);
            }
        });



        return view;
    }

}